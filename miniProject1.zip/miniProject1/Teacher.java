/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miniProject1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class Teacher extends Users {
	
	void Login() {
		   
		
	   
       String username;
       String password;

       // Used to hold the instance of a user who successfully logged in
       Users loggedInUser = null;

       // Create an empty list to hold users
       List<Users> listOfUsers = new ArrayList<>();

       // Add 3 users to the list
       listOfUsers.add(new Users("Vipul025","Vipul025"));
       listOfUsers.add(new Users("Nisha026","Nisha026"));
       listOfUsers.add(new Users("Kiran027","Kiran027"));

       // Get user input
       Scanner br = new Scanner(System.in);
    

       System.out.println("****WELCOME TO TEACHER's SCREEN****\n");
       

       System.out.println("Please Type Your Username :");
       username = br.next();   
       System.out.println("Please Type Your Password :");
       password = br.next();

       // Iterate through list of users to see if we have a match
       for (Users user : listOfUsers)
       {
           if (user.getUsername().equals(username))
           {
               if (user.getPassword().equals(password))
               {
                   loggedInUser = user;

                   // when a user is found, "break" stops iterating through the list
                 
                   break;
                   
               }
           }
       }

       // if loggedInUser was changed from null, it was successful
       
       if (loggedInUser != null)
       {
           System.out.println("User successfully logged in: "+loggedInUser.getUsername());
           ShowDetail();
       }
       else
       {
           System.out.println("Invalid username/password combination");
           
       }
       
   }
	
	   
    static void Display() {
        
                 String str1="VIPUL";
                 String str2="KIRAN";
                 String str3="NISHA";
                 Scanner s=new Scanner(System.in);
                 while(true){
                 System.out.println("***********************************************");
                 System.out.println("ENTER YOUR PROFILE FIRST NAME [IN BLOCK LETTER]:- ");
                 String name_S = s.next();
        try
          { 
           if(str1.equals(name_S) && !str2.equals(name_S) && !str3.equals(name_S))
           {
   	     String Teacher_ID =" Vipul_024_KH";
 	     String name  =  "VIPUL TEMBULWAR";
 	     String Subject = "LAB";
 	     String city = "MUMBAI";
 	     char Gender = 'M';
 	     float Salary =  50000;
 	     
 	     
 	    System.out.println("****************************************************"); 
            System.out.println("                PROFILE                        ");
 	    System.out.println("       Teacher_ID  :"+Teacher_ID+ " \n       NAME        : " +name+"\n       SUBJECT     : " +Subject + " \n       GENDER      : " +Gender+ " \n       CITY        : " +city+ " \n       SALARY      : ₹ "+Salary);
 	    System.out.println("****************************************************"); 
            break;
	  
	    }
           else if(str2.equals(name_S) && !str1.equals(name_S) && !str3.equals(name_S))
                   {
                        String Teacher_ID =" Kiran_025_KH";
                        String name  =  "KIRAN WAGHMARE";
                        String Subject = "PROGRAMMING CONCEPTS";
                        String city = "MUMBAI";
                        char Gender = 'F';
                        float Salary =110000;
 	     
 	     
                        System.out.println("****************************************************");
                        System.out.println("                PROFILE                        ");
                        System.out.println("       Teacher_ID  :"+Teacher_ID+ " \n       NAME        : " +name+"\n       SUBJECT     : " +Subject + " \n       GENDER      : " +Gender+ " \n       CITY        : " +city+ " \n       SALARY      : ₹ "+Salary);
                        System.out.println("****************************************************");
                        break;
                   }
           else if(str3.equals(name_S) && !str1.equals(name_S) && !str2.equals(name_S))
                   {
                        String Teacher_ID =" Nisha_026_KH";
                        String name  =  "NISHA KAROLIA";
                        String Subject = "LAB";
                        String city = "MUMBAI";
                        char Gender = 'F';
                        float Salary =50000;
 	     
 	     
                        System.out.println("****************************************************");
                        System.out.println("                PROFILE                        ");
                        System.out.println("       Teacher_ID  :"+Teacher_ID+ " \n       NAME        : " +name+"\n       SUBJECT     : " +Subject + " \n       GENDER      : " +Gender+ " \n       CITY        : " +city+ " \n       SALARY      : ₹ "+Salary);
                        System.out.println("****************************************************");
                        break;
                   }
           else{
                     System.out.println("***********YOUR NAME IS WRONG***********");
                     break;
                 }
            }
         catch(Exception e){
            System.out.println("You Have Written Wrong Details");
        }
        }
       
    }
	
	
	
	
	void ShowDetail()
    {
        try{
        int a;
        do
        {
            System.out.println("\n[1]TEACHER DETAILS.");
            System.out.println("[2]MAKE RESULT.");
            System.out.println("[3]LOGOUT");
            System.out.println("[CHOOSE CHOICE]");
            
            Scanner sc=new Scanner(System.in);
            a=sc.nextInt();
            System.out.println("");
          try{
            switch(a)
            {
                case 1:
                     Display(); 
                     break;
                case 2:
                    EditResult();
                    break;
                case 3:
                    
                default:
                    System.out.println("Enter valid details");
            }
          }
          catch(Exception e){
              System.out.println("Enter valid details");
          }
        }while(a!=3);
    }
        catch(Exception e){
             System.out.println("Enter valid details");
        }
    }
        
    public void EditResult()
    {
        try{
             int marks[] = new int[7];    //we are taking an array here.
        int i = 0;
        int Class;
        char ch = 0;
        float total=0, avg;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Student Roll Number = ");
        String studentId=scanner.next();
	Scanner sc = new Scanner(System.in);
        System.out.println("Enter Student name = ");
        String name=sc.nextLine();
          
    while(true)
    {
       System.out.println("Enter Student Class = ");
       Class=scanner.nextInt();
     if(Class <= 12 && Class >= 1)
     {
           
        for(i=0; i<6; i++) { 
           System.out.print("Enter Marks of Module"+(i+1)+":");
            
           marks[i] = scanner.nextInt();
         if(marks[i]>=0 && marks[i]<=100){
           total = total + marks[i];
        }
        else{
              System.out.println("*****************************************************");
              System.out.println("Marks Range Is Wrong(Select in b/w 0-100)");
              System.out.println("*****************************************************");i--;}}
             
     //   scanner.close();   // Due to this exception is occuring
        //Calculating average here
         
        avg = total/6;
       //if(marks[i]>=0 && marks[i]<=100){
        System.out.print("The student Grade is: ");
        if(avg>=80)
        {
            System.out.print(ch='A');
        }
        else if(avg>=60 && avg<80)
        {
           System.out.print(ch='B');
        } 
        else if(avg>=40 && avg<60)
        {
            System.out.print(ch='C');
        }
        else if(avg>=33 && avg<40)
        {
            System.out.print(ch='D');
        }
        else
        {
            System.out.print(ch='F');
        }
        break;
         }
    else{
           System.out.println("You have Written Wrong Class");
           break;
        }
    //break;
    }
  
 
  
    
   
    //if(marks[i]<=0 && marks[i]<=100){
        System.out.println("\n*****************************************");
        System.out.println("*************REPORT CARD*****************");
        System.out.println("**      NAME:-        "+name);
        System.out.println("**      CLASS:-       "+ Class);
        System.out.println("**      ROLL NUMBER:- "+ studentId);
        System.out.println("**      GRADE:-       "+ ch);
        System.out.println("***********MARKS OBTAINED****************");
       for(i=0;i<6;i++)
       {
        System.out.println("**      MODULE["+(i+1)+"]:-        "+marks[i]);
       }
        System.out.println("******************************************");
        System.out.println("**    TOTAL MARKS OBTAINED :-   "+total);
      
        System.out.println("******************************************");
        System.out.println("******************************************");
    }
       /* else{
              System.out.println("*****************************************************");
              System.out.println("Marks Range Is Wrong(Select in b/w 0-100)");
              System.out.println("*****************************************************");*/
                      
        
        catch(Exception e)
        {
            System.out.println("You have written wrong details for edit result");
        }
    
    }}
 
