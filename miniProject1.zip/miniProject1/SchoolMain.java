/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miniProject1;

import java.util.Scanner;

public class SchoolMain {
    public static void main(String args[])
    {
    	  int Choice = 0;
	  System.out.println("*****************************************************");
          System.out.println("*******************||WELCOME TO||********************");
          System.out.println("**************||KHARGAR PUBLIC SCHOOL||**************");
          System.out.println("*****************************************************");
          System.out.println("*****************************************************");

       do {
                    System.out.println("**********MAIN MENU************");
	    	    System.out.println("**    1. Student Section     **");
	    	    System.out.println("**    2. Teacher Section     **");
	    	    System.out.println("**    3. Exit                **");
	    	    System.out.println("*******************************");
                    System.out.print("ENTER CHOICE :- ");
	    	   
            try{
               Scanner s  = new Scanner (System.in);
               Choice = s.nextInt();
          
               switch(Choice) {
          
                 case 1 :   Student s1 = new Student();
                           s1.Login();
                           
                           break;
          
                 case 2:   Teacher t1 = new Teacher();
                           t1.Login();
                           break;
          
                 case 3:
	    	    	   break;
	    	    	   
	    	    	   default:  System.out.println("Enter valid detail");
          
          
          
          }
         
       }
       
     catch(Exception e)
          {
              System.out.println("Enter valid detail");
          }
       }while(Choice!=3);

  }
    

}
    
