/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miniProject1;

import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.UUID;






import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;





class Users {
    private  String username;
    private  String password;
    
   Users(){
    	
     }

    Users (String username, String password)
    {
        this.username = username;
        this.password = password;
    }

    String getUsername() {return username;}
    String getPassword() {return password;}
		   
	   
 }

class Student extends Users {
    static int fees;
    static int feesPaid=0;
    static int feesTotal=30000;
   
   
	
	     void Login() {
		   
	        String username;
	        String password;
               

	        // Used to hold the instance of a user who successfully logged in
	        Users loggedInUser = null;

	        // Create an empty list to hold users
	        List<Users> listOfUsers = new ArrayList<>();

	        // Add 3 users to the list
	        listOfUsers.add(new Users("mayank023","mayank023"));
	        listOfUsers.add(new Users("amit123","amit123"));
	        listOfUsers.add(new Users("srk123","srk123"));

	        // Get user input
	        Scanner br = new Scanner(System.in);
	      

	        System.out.println("**********WELCOME TO STUDENT SCREEN**********\n");

	        System.out.println("Please Type Your Username :");
	        username = br.next();   
	        System.out.println("Please Type Your Password :");
	        password = br.next();

	        // Iterate through list of users to see if we have a match
	        for (Users user : listOfUsers)
	        {
	            if (user.getUsername().equals(username))
	            {
	                if (user.getPassword().equals(password))
	                {
	                    loggedInUser = user;

	                    // when a user is found, "break" stops iterating through the list
	                  
	                    break;
	                    
	                }
	            }
	        }

	        // if loggedInUser was changed from null, it was successful
	        if (loggedInUser != null)
	        {
	            System.out.println("User successfully logged in: "+loggedInUser.getUsername());
	            Student();
	        }
	        else
	        {
	            System.out.println("Invalid username/password combination");
	        }
	    }
	     
	     static void Display() {
                  
                 String str1="AMIT";
                 String strU="amit123";
                 String strU1="mayank023";
                 String strU2="srk123";
                 String str2="MAYANK";
                 String str3="SHAH";
                 Scanner s=new Scanner(System.in);
                 while(true){
                 System.out.println("***********************************************");
                 System.out.println("ENTER YOUR PROFILE FIRST NAME [IN BLOCK LETTERS]:- ");
                 String name_S = s.next();
                 try{
                 if(str1.equals(name_S) && !str2.equals(name_S) && !str3.equals(name_S) /*&& strU.equals(username)*/)
                 {
                    int student_ID = 2020_01;
                    String name="AMIT WALUNJ";
                    int  Class =10;
                    String city = "PUNE";
                    char Gender = 'M';
      	     
                    System.out.println("***********************************************"); 
                    System.out.println("       STUDENT_ID   :  "+student_ID+ " \n       NAME         :  " +name+"\n       CLASS        :  "+Class+ " \n       GENDER       :  "+Gender+ " \n       CITY         :  "+city);
                    System.out.println("***********************************************"); 
                    break;
                 }
                 
                 else if(str2.equals(name_S) && !str1.equals(name_S) && !str3.equals(name_S)  /*&& strU1.equals(username)*/)
                 {
                     int student_ID = 2020_02;
                     String name="MAYANK RAJ YADAV";
                     int  Class =12;
                     String city = "BHOPAL";
                     char Gender = 'M';
      	     
                     System.out.println("***********************************************"); 
                     System.out.println("       STUDENT_ID   :  "+student_ID+ " \n       NAME         :  " +name+"\n       CLASS        :  "+Class+ " \n       GENDER       :  "+Gender+ " \n       CITY         :  "+city);
                     System.out.println("***********************************************"); 
                     break;
                 }
                 
                 else if(str3.equals(name_S) && !str1.equals(name_S) && !str2.equals(name_S) /*&& strU2.equals(username)*/)
                 {
                     int student_ID = 2020_02;
                     String name="SHAH RUKH KHAN";
                     int  Class =12;
                     String city = "DELHI";
                     char Gender = 'M';
      	     
                     System.out.println("***********************************************"); 
                     System.out.println("       STUDENT_ID   :  "+student_ID+ " \n       NAME         :  " +name+"\n       CLASS        :  "+Class+ " \n       GENDER       :  "+Gender+ " \n       CITY         :  "+city);
                     System.out.println("***********************************************"); 
                    break;
                 }
                 }
                 catch(Exception e)
                 {
                     System.out.println("Enter valid Details");
                 }
                 
                 }
   	    }
	     
	      void feesPay(int fees)
         {
             String treId= UUID.randomUUID().toString();
           feesPaid= feesPaid + fees ;
   	       System.out.println("******************************************************"); 
           System.out.println("Your Transaction Is Succesful   : "+feesPaid);
           System.out.println("Transaction Id : "+treId);
   	       System.out.println("******************************************************"); 
         }
	      
	    
	    
	     
         void remainingFees()
          {
              float remainingFees= feesTotal-feesPaid;
      	   
              System.out.println("***********************************"); 
              System.out.println("REMANINING FEES  : "+remainingFees);
      	      System.out.println("***********************************"); 
          }
         
   	       
	     void Student(){
                
	    	 int Choice = 0;
	    	do {
                    
                     try{
	    	   System.out.println("1. Student Profile");
	    	    System.out.println("2. Payfees");
	    	    System.out.println("3. Remaining Fees");
	    	    System.out.println("4. Logout");
	    	    
	    	    
	    	    
	    	    Scanner sc1=new Scanner(System.in);
	    	    
	    	     Choice=sc1.nextInt();
	    	    switch(Choice)
	    	    {
	    	       case 1:
	    	    	   Student.Display();
	    	    	   break;
	    	       case 2:
                           while(true){
	    	    	   System.out.println("Enter Fees You Want To Pay");
	    	    	   int fees=sc1.nextInt();
                           if(fees>0 && fees<=30000 )
                           {
	    	    	   feesPay(fees);
                           break;
                           }
                           else{
                               System.out.println("***!!!PLEASE TYPE VALID FEES!!!***");
                           }}
	   	    	      //   if(b1==2){
	   	    	    	// feesPay(fees);
	   	    	        // }
	    	    	  // break;
	    	       case 3 :
	    	    	   remainingFees();
	    	    	   break;
	    	       case 4:  System.out.println("********************************** ");
	    	    	   break;
	    	    	   default: System.out.println("Enter valid details");
	    	    }}
                 catch(Exception e){
                     System.out.println("Enter valid details");
                 }
                }
	    	while(Choice!=4);
                 
	    	  
	     }
}